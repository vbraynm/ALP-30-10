#include <stdio.h>
int main()
{
    int i = 0;
    while(i < 5){
        i++;
        printf("%i\n", i);
    }

}
