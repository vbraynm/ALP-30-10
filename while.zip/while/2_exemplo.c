#include <stdio.h>
int main()
{
    int contadora = 0;
    while (contadora < 10)
    {
        printf("Hello World!\n");
        contadora++;
    }
    return 0;
}
